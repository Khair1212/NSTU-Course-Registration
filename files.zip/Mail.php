<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
   <title>Section Officer Workplace</title>
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <style>
    
      a:hover
      {
      background-color: green;
      /* font-color:red; */
      }

	  body{color:white;
	background-color:#37334d;}
    
    </style>



<nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      <label class="logo">NCR</label>
      <ul>
	    <li><a href="sectionOfficer.php">Home</a></li>
        <li><a class="" href="studentsRegistration.php">Student Registration</a></li>
        <li><a href="sectionOfficerMail.php">New Application</a></li>
        <li><a href="addCourse.php">Course</a></li>
        <li><a href="uploadForm.php">Notice Upload</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="logout.php">Log Out</a></li>
      </ul>
    </nav>

  </head>
  <body>
 
 
<!-- Messages -->
<br><br>
  <div class="col-md-12">
  <div class="container">
    <div class="card text-center">
    <div class="card-header">
      <h5 style="float: left;"></h5>
    </div>
    <div class="card-body">
      <h2 class="ti"><strong>All Messages</strong></h2>
      <table class="table">
        
    <thead class="thead-light">
      <tr>
        <th scope="col">#</th>
        <th scope="col">From</th>
        <th scope="col">Subject</th>
        <th scope="col">Short Message</th>
        <th scope="col">File </th>
        <th scope="col">Action</th>
        <th scope="col">Action</th>
      </tr>
    </thead>
    <tbody>

      <?php
      include("config.php");
      $i = 0;
          $sel="SELECT * FROM mail ORDER BY mail_id DESC";
          $Q=mysqli_query($con,$sel);
          while($data=mysqli_fetch_assoc($Q)){
      ?>
      <tr>
        <th scope="row"><?php echo ++$i; ?></th>
        <td><?= $data['fromm']; ?></td>
        <td><?= $data['subject']; ?></td>
        <td><?= $data['message']; ?></td>
        <td><a href="images/<?= $data['file']; ?>" target="_blank">Click to see</a></td>
        
        <td>
          <a href="sectionOfficerMail.php?e=<?= $data['mail_id']; ?>" class="btn btn-primary">Reply</a>
          <a href="deleteSOMail.php?d=<?= $data['mail_id']; ?>" class="btn btn-primary"><i class="fa fa-trash" aria-hidden="true"></i></a> 
        </td>
        <td>
          <a href="upload.php?file=<?= $data['file']; ?>" class="btn btn-primary">Publish</a>
        </td>
      </tr>
    <?php } ?>
    </tbody>
  </table>
  </div>
  </div>
</div>


  </body>
</html>