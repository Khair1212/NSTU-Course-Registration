<?php
   include("config.php");
    $id=$_GET['d'];
    $del="DELETE FROM courses WHERE course_code ='$id'";
    mysqli_query($con,$del);
    header('Location: addCourse.php');
?>