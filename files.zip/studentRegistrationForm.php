<?php


    $db_name="multiuser";
    $db_host="localhost";
    $db_user="root";
    $db_pass="";
    $con=mysqli_connect($db_host,$db_user,$db_pass,$db_name);
    if(!$con){
      echo "Database connection error.";
    }else {
      //echo "connection successfull.";
    }



if(!empty($_POST)){
  $department = $_POST['department'];
  $name= $_POST['name'];
  $year = $_POST['year'];
  $term = $_POST['term'];
  $roll = $_POST['roll'];
  $email = $_POST['email'];
  $mobile = $_POST['mobile'];
  $password = md5($_POST['password']);
  $cpassword = md5($_POST['cpassword']);
  
  if (!empty($email)){
	if(!empty($roll)){
	if ( $password == $cpassword) {
	  $insert="INSERT INTO student_details (Department, Name, Year, Term, Roll, Email, Mobile, Password)
	  VALUES('$department', '$name', '$year', '$term', $roll, '$email', '$mobile', '$cpassword')";
	  
      if(mysqli_query($con,$insert)){
		  echo '<script>alert("Registration Completed successfully")</script>';
	  }else{
		  echo '<script>alert("Registration Failed! Please, Try Again")</script>';
	    }
    }
}
 }
	}

 ?>





<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="studentRegisterForm.css">
    <title>Document</title>
    

<!-- <script>
 var app = angular.module('MyApp');
app.controller('DemoCtrl', function($scope) {
		$scope.user = {
				first_name: '',
				last_name: '',
				gender: '',
				age: '',
				email: '',
		};
});
app.directive("compareTo", function() {
		return {
				require: "ngModel",
				scope: {
						otherModelValue: "=compareTo"
				},
				link: function(scope, element, attributes, ngModel) {

						ngModel.$validators.compareTo = function(modelValue) {
								return modelValue == scope.otherModelValue;
						};

						scope.$watch("otherModelValue", function() {
								ngModel.$validate();
						});
				}
		};
});
</script> -->

<style>
.main{
    
  width: 40%;
  border: 5px solid black;
  padding: 30px;
  margin-top: 100px;
  margin: auto;
  box-shadow: 2px 2px green;
  

}
</style>




</head>
<body>
  
    <div class="main">
    <div ng-controller="DemoCtrl" ng-cloak="" class="md-inline-form" ng-app="MyApp" layout="column" layout-sm="row" layout-align="center center" layout-align-sm="start start" layout-fill>
		<md-content id="SignupContent" class="md-whiteframe-10dp" flex-sm>
				<h2>Student Details Entry Form</h2></br>

                <form action="" class="reg" method="post">
				<div layout-padding="">
						<div name="userForm" method="POST" action="" ng-submit="user.submit(userForm.$valid)" enctype="multipart/form-data">
                                <input type="hidden" name="action" value="signup" />
                                
                                <div layout="row" layout-sm="column">
                                <md-input-container flex-gt-sm="">
                                        <label>Department name</label>
                                        <input ng-model="user.department" name="department" required type="text"  placeholder="Software Engineering">
                                        
                                </md-input-container>
                            </div><br>

								<div layout="row" layout-sm="column">
										<md-input-container flex-gt-sm="">
												<label>Student fullname</label>
												<input ng-model="user.first_name" name="name" required type="text"  placeholder="Your Fullname">
												
										
                                </div></md-content><br>
                                <div layout="row" layout-sm="column">
                                    <md-input-container flex-gt-sm="">
                                            <label>Year no</label>
                                            <input required type="number" step="any" name="year" ng-model="user.year" min="1" max="5" placeholder="3" />
                                            
                                    </md-input-container>
                                    <md-input-container flex-gt-sm="">
                                            <label>Term no</label>
                                            <input required type="number" step="any" name="term" ng-model="user.term" min="1" max="2" placeholder="1" />
								<div layout="row" layout-sm="column"></div></br>
                                       
										<md-input-container flex-gt-sm="60">
												<label>Batch</label>
												<input required type="number" step="any" name="age" ng-model="user.age" min="1" max="16" placeholder="13" /></form>
												<div ng-if="userForm.age.$dirty" ng-messages="userForm.age.$error" role="alert" multiple>				
										</md-input-container>
                                </div>
                            </br>

                            <div layout="row" layout-sm="column">
                                <md-input-container flex-gt-sm="">
                                        <label>Roll no</label>
                                        <input ng-model="user.roll" name="roll" required type="text"placeholder="ASH1825037M">
                                        
                                </md-input-container>
                            </div><br>


								<div layout="row" layout-sm="column">
										<md-input-container flex-gt-sm="">
												<label>Email</label>
												<input required type="email" name="email" ng-model="user.email" ng-pattern="/^[_a-z0-9-+]+(\.[_a-z0-9-+]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,4})$/" placeholder="ash1825037m@gmail.com" />
												<div ng-if="userForm.email.$dirty" ng-messages="userForm.email.$error" role="alert">			
										</md-input-container>
                                </div></md-content></br>
                                
                                <div layout="row" layout-sm="column">
                                    <md-input-container flex-gt-sm="">
                                            <label>Mobile no</label>
                                            <input ng-model="user.mobile" name="mobile" required type="text"  length="11" placeholder="01*********">
                                            
                                    </md-input-container>
                                </div><br>

								<div layout="row" layout-sm="column">
										<md-input-container flex-gt-sm="">
												<label>Password</label>
												<input name="password" ng-model="user.password" type="password" minlength="8" maxlength="100" ng-pattern="/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/" required placeholder="Atleast 8 characters">
												<div ng-if="userForm.password.$dirty" ng-messages="userForm.password.$error" role="alert" multiple>
														
												</div></md-input-container></br>
										</md-input-container>
										<md-input-container flex-gt-sm="">
												<label>Retype</label>
												<input name="cpassword" ng-model="user.confmPassword" type="password" minlength="8" maxlength="100" ng-pattern="/(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}/" required compare-to="user.password" placeholder="Same as Password">
												<div ng-if="userForm.confmPassword.$dirty" ng-messages="userForm.confmPassword.$error" role="alert">
												
                                        </md-input-container></br>
                                        <!-- <p>Gender:</p> -->
										<input type="radio" id="male" name="gender" value="male">
                                        <label for="male">Male</label>
                                        <input type="radio" id="female" name="gender" value="female">
                                        <label for="female">Female</label>
                                        <input type="radio" id="other" name="gender" value="other">
                                        <label for="other">Other</label></br>
                                     </div> </br> 
                                        <p style="color:red;">Are you sure above all information is correct?</p>
								</div></br>
								<input type="submit" style="width:10%; margin: 0px 0px; background-color:green;" ng-disabled="userForm.$invalid" name="Submit"></input>
						</form>
				</div>
                </form>
		</md-content>
</div>
</div>





</body>
</html>