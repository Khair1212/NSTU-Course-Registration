<?php

$servername="localhost";
$username="root";
$password="";
$dbname="multiuser";

$conn = mysqli_connect($servername, $username,$password, $dbname);

 //echo "Connected";

 //include("config.php");

?>


<!DOCTYPE html>
<!-- <html xmlns="http://www.w3.org/1999/xhtml"> -->
<head>
<title>Notice</title>
<link rel="stylesheet" href="upload.css" type="text/css" />
<link rel="stylesheet" href="style.css">
<script src="https://kit.fontawesome.com/a076d05399.js"></script>
</head>
<body>


<div>
    <nav>
      <input type="checkbox" id="check">
      <label for="check" class="checkbtn">
        <i class="fas fa-bars"></i>
      </label>
      <label class="logo">NCR</label>
      <ul>
        <li><a href="student.php">Home</a></li>
        <li><a href="#">Services</a></li>
        <li><a href="studentContact.html">Contact</a></li>
        <!-- <li><a href="#">Feedback</a></li> -->
        <li><a href="profile.html">Profile</a></li>
        <li><a href="logout.php">Log Out</a></li>
      </ul>
      </nav>
      </div>


<div id="header">
<label>Emergency Notice for Student</label>
</div>
<div id="body">

 <table width="80%" border="1">
    <tr>
    <th colspan="2">Important Notice<label></label></th>
    <!-- <a href="uploadForm.php">upload new files...</a> -->
    </tr>
    <tr>
    <td>File Name</td>
    <!-- <td>File Type</td>
    <td>File Size(KB)</td> -->
    <td>View</td>
    </tr>

    <?php
 $sql="SELECT * FROM uploadform";
 $result_set = mysqli_query($conn,$sql);
 while($row=mysqli_fetch_array($result_set))
 {
  ?>
        <tr>
        <td><?php echo $row['file'] ?></td>
        <!-- <td><?php echo $row['type'] ?></td>
        <td><?php echo $row['size'] ?></td> -->
        <td><a href="images/<?php echo $row['file'] ?>" target="_blank">view file</a></td>
        </tr>
        <?php
 }
 ?>
    </table>
    
</div>

</body>
</html>