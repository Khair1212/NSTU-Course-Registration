<?php
   include("config.php");
    $id=$_GET['d'];
    $del="DELETE FROM mail WHERE mail_id ='$id'";
    mysqli_query($con,$del);
    header('Location: Mail.php');
?>