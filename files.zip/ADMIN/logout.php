 <?php

// session_start();

// unset($_session['email']);

// header("location: Login.php");

session_start();
echo "<script>window.location.assign('login.php')</script>";
session_destroy();


?> 