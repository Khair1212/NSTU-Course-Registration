<?php
   include("config.php");
    $id=$_GET['d'];
    $del="DELETE FROM hall WHERE hall_id='$id'";
    mysqli_query($con,$del);
    header('Location: hall.php');
?>