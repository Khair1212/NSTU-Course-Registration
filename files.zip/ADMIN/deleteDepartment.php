<?php
   include("config.php");
    $id=$_GET['d'];
    $del="DELETE FROM departments WHERE dept_id='$id'";
    mysqli_query($con,$del);
    header('Location: addDepartment.php');
?>